<script>
  import Header from "./UI/Header.svelte";
  import MeetupItem from "./Meetups/MeetupItem.svelte";

  const meetups = [
    {
      id: "m1",
      title: "Meetup title",
      subtitle: "subtitle",
      description: "description lorem ",
      imageUrl:
        "https://f0.pngfuel.com/png/147/747/star-wars-millennium-falcon-png-clip-art-thumbnail.png",
      address: "215th what ever, 151 NY",
      contactEmail: "asian@devastation.xx"
    },
    {
      id: "m1",
      title: "happy swimmers",
      subtitle: "subtitle",
      description: "this is the description",
      imageUrl:
        "https://f0.pngfuel.com/png/1012/879/gray-and-black-spaceship-clip-art-png-clip-art-thumbnail.png",
      address: "215th what ever, 151 NY",
      contactEmail: "black@attack.xx"
    }
  ];
</script>

<Header />
{#each meetups as meetup}
  <MeetupItem />
{/each}
